#include "LightClass.h"



LightClass::LightClass()
{
}

LightClass::LightClass(const LightClass &other)
{
}


LightClass::~LightClass()
{
}

void LightClass::SetDiffuseColor(D3DXVECTOR4 diffuseColor)
{
	m_diffuseColor = diffuseColor;
	return;
}

void LightClass::SetDirection(D3DXVECTOR3 dir)
{
	m_direction = dir;
	return;
}

D3DXVECTOR4 LightClass::GetDiffuseColor()
{
	return m_diffuseColor;
}

D3DXVECTOR3 LightClass::GetDirection()
{
	return m_direction;
}
