#include "GraphicsClass.h"



GraphicsClass::GraphicsClass()
{
	m_D3D = 0;
	m_Camera = 0;
	m_Model = 0;
	m_LightShader = 0;
	m_Light = 0;
	m_TextureShader = 0;
	m_Bitmap = 0;
	m_Text = 0;
	m_ModelList = 0;
	m_Frustum = 0;
}

GraphicsClass::GraphicsClass(const GraphicsClass &other)
{
}


GraphicsClass::~GraphicsClass()
{
}

bool GraphicsClass::Initialize(int screenWidth, int screenHeight, HWND hwnd)
{
	bool result;
	D3DXMATRIX baseViewMatrix;
	// Direct3D ��ü ����
	m_D3D = new D3DClass;
	if (!m_D3D) {
		return false;
	}

	// Direct3D ��ü �ʱ�ȭ
	result = m_D3D->Initialize(screenWidth, screenHeight, VSYNC_ENABLED, hwnd, FULL_SCREEN, SCREEN_DEPTH, SCREEN_NEAR);
	if (!result) {
		MessageBox(hwnd, L"Could not initialize Direct3D", L"Error", MB_OK);
		return false;
	}

	// Camera ��ü ����
	m_Camera = new CameraClass;
	if (!m_Camera) {
		return false;
	}
	// ī�޶� �⺻ ������ ����
	m_Camera->SetPosition(D3DXVECTOR3(0.0f, 30.0f, -150.0f));
	m_Camera->Render();
	m_Camera->GetViewMatrix(baseViewMatrix);

	m_Text = new TextClass;
	if (!m_Text) {
		return false;
	}
	result = m_Text->Initialize(m_D3D->GetDevice(), m_D3D->GetDeviceContext(), hwnd, screenWidth, screenHeight, baseViewMatrix);
	if (!result) {
		MessageBox(hwnd, L"Could not initialize the text object. ",L"Error" ,MB_OK);
		return false;
	}
//  // Model ��ü ����
//  m_Model = new ModelClass;
//  if (!m_Model) {
//  	return false;
//  }
//  // Model ��ü �ʱ�ȭ
//  result = m_Model->Initialize(m_D3D->GetDevice() ,(char*)"../Engine/data/cube.txt",(WCHAR*)L"../Engine/data/seafloor.dds",(std::string)"../Engine/testModels/idle01.fbx");
//  if (!result) {
//  	MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
//  	return false;
//  }
//  
//  // Shader ��ü ����
//  m_LightShader = new LightShaderClass;
//  if (!m_LightShader) {
//  	return false;
//  }
//  // Shader ��ü �ʱ�ȭ
//  result = m_LightShader->Initialize(m_D3D->GetDevice(), hwnd);
//  if (!result) {
//  	MessageBox(hwnd, L"Count not initialize the Texture shader object.", L"Error", MB_OK);
//  	return false;
//  }
//  
//  // ���� ��ü ����
//  m_Light = new LightClass;
//  if (!m_Light) {
//  	return false;
//  }
//  
//  // ���� ��ü �ʱ�ȭ
//  m_Light->SetAmbientColor(D3DXVECTOR4(0.15f, 0.15f, 0.15f, 1.0f));
//  m_Light->SetDiffuseColor(D3DXVECTOR4(1.0f, 1.0f, 1.0f, 1.0f));
//  m_Light->SetDirection(D3DXVECTOR3(0.0f, 0.0f, 1.0f));
//  m_Light->SetSpecularColor(D3DXVECTOR4(1.0f, 1.0f, 1.0f, 1.0f));
//  m_Light->SetSpecularPower(32.0f);

// m_TextureShader = new TextureShaderClass;
// if (!m_TextureShader) {
// 	return false;
// }
// result = m_TextureShader->Initialize(m_D3D->GetDevice(), hwnd);
// if (!result) {
// 	MessageBox(hwnd, L"Could not initialize the texture shader object", L"Error", MB_OK);
// 	return false;
// }
// m_Bitmap = new BitmapClass;
// if (!m_Bitmap) {
// 	return false;
// }
// result = m_Bitmap->Initialize(m_D3D->GetDevice(), screenWidth, screenHeight, (WCHAR*)L"../Engine/data/seafloor.dds", 256, 256);
// if (!result) {
// 	MessageBox(hwnd, L"Could not initialize the bitmap object", L"Error", MB_OK);
// 	return false;
// }

// Create the model object.
	m_Model = new ModelClass;
	if (!m_Model)
	{
		return false;
	}

	// Initialize the model object.
	result = m_Model->Initialize(m_D3D->GetDevice(), (char*)"../Engine/data/sphere.txt", (WCHAR*)L"../Engine/data/seafloor.dds");
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
		return false;
	}

	m_LightShader = new LightShaderClass;
	if (!m_LightShader)
	{
		return false;
	}

	result = m_LightShader->Initialize(m_D3D->GetDevice(), hwnd);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the light shader object.", L"Error", MB_OK);
		return false;
	}

	m_Light = new LightClass;
	if (!m_Light)
	{
		return false;
	}

    m_Light->SetAmbientColor(D3DXVECTOR4(0.15f, 0.15f, 0.15f, 1.0f));
    m_Light->SetDiffuseColor(D3DXVECTOR4(1.0f, 1.0f, 1.0f, 1.0f));
    m_Light->SetDirection(D3DXVECTOR3(0.0f, 0.0f, 1.0f));
    m_Light->SetSpecularColor(D3DXVECTOR4(1.0f, 1.0f, 1.0f, 1.0f));
    m_Light->SetSpecularPower(32.0f);

	m_ModelList = new ModelListClass;
	if (!m_ModelList)
	{
		return false;
	}

	result = m_ModelList->Initialize(25);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the model list object.", L"Error", MB_OK);
		return false;
	}

	m_Frustum = new FrustumClass;
	if (!m_Frustum)
	{
		return false;
	}

	return true;
}

void GraphicsClass::Shutdown()
{
	if (m_Frustum)
	{
		delete m_Frustum;
		m_Frustum = 0;
	}
	if (m_ModelList)
	{
		m_ModelList->Shutdown();
		delete m_ModelList;
		m_ModelList = 0;
	}
	if (m_Text) {
		m_Text->Shutdown();
		delete m_Text;
		m_Text = 0;
	}
	if (m_Bitmap) {
		m_Bitmap->Shutdown();
		delete m_Bitmap;
		m_Bitmap = 0;
	}
	// ���� ��ü ����
	if (m_Light) {
		delete m_Light;
		m_Light = 0;
	}
	// Shader ��ü ����
	if (m_LightShader) {
		m_LightShader->Shutdown();
		delete m_LightShader;
		m_LightShader = 0;
	}

	// Model ��ü ����
	if (m_Model) {
		m_Model->Shutdown();
		delete m_Model;
		m_Model = 0;
	}

	// Camera ��ü ����
	if (m_Camera) {
		delete m_Camera;
		m_Camera = 0;
	}

	// D3D ��ü ����
	if (m_D3D) {
		m_D3D->Shutdown();
		delete m_D3D;
		m_D3D = 0;
	}
	return;
}

bool GraphicsClass::Frame(int mouseX,int mouseY,float frameTime,int fps ,int cpu,float rotY)
{
	bool result;
    static float rotation = 0.0f;
    
    rotation += (float)D3DX_PI * 0.005f;
    // �� ������ ���� ȸ�� ���� ������Ʈ ���ݴϴ�.
    if (rotation > 360.0f) {
    	rotation -= 360.0f;
    }
    // �׷��� ������ ����
    result = Render(rotation);
    if (!result) {
    	return false;
    }
	m_Camera->SetPosition(D3DXVECTOR3(0.0f, 0.0f, -10.0f));
	m_Camera->SetRotation(D3DXVECTOR3(0.0f, rotY, 0.0f));

 	result = m_Text->SetFps(fps, m_D3D->GetDeviceContext());
 	if (!result) {
 		return false;
 	}
 
 	result = m_Text->SetCpu(cpu, m_D3D->GetDeviceContext());
 	if (!result) {
 		return false;
 	}
 
 	result = m_Text->SetMousePosition(mouseX, mouseY, m_D3D->GetDeviceContext());
 	if (!result) {
 		return false;
 	}
	return true;
}

bool GraphicsClass::Render(float rotation)
{
	D3DXMATRIX worldMatrix, viewMatrix, projectionMatrix, orthoMatrix, temp;
	int modelCount, renderCount, index;
	float positionX, positionY, positionZ, radius;
	D3DXVECTOR4 color;
	bool result, renderModel;

	// ���� �ʱ�ȭ
	m_D3D->BeginScene(0.5f, 0.5f, 0.5f, 1.0f);

	// ī�޶� ��ġ�� ���� �� ����� �����մϴ�.
	m_Camera->Render();

	// ī�޶� �� d3d ��ü���� ����,�� �� �������� ����� �����ɴϴ�
	m_Camera->GetViewMatrix(viewMatrix);
	m_D3D->GetWorldMatrix(worldMatrix);
	m_D3D->GetProjectionMatrix(projectionMatrix);
	m_D3D->GetOrthoMatrix(orthoMatrix);
//  //  �ﰢ���� ȸ�� �� �� �ֵ��� ȸ�� ������ ���� ����� ȸ���մϴ�.
//  
//  m_D3D->TurnZBufferOff();
//  // �� ���ؽ��� �ε��� ���۸� �׷��� ������ ���ο� ��ġ�Ͽ� ������� �غ��մϴ�.
//  m_Model->Render(m_D3D->GetDeviceContext());
//  
//  // Light Shader�� ����Ͽ� ���� ������ �մϴ�.
//  result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,m_Model->GetTexture(),m_Light->GetDirection(),m_Light->GetDiffuseColor() , m_Light->GetAmbientColor()
//  ,m_Camera->GetPosition(),m_Light->GetSpecularColor(),m_Light->GetSpecularPower());
//  if (!result) {
//  	return false;
//  }


	m_Frustum->ConstructFrustum(SCREEN_DEPTH, projectionMatrix, viewMatrix);
	modelCount = m_ModelList->GetModelCount();
	renderCount = 0;

	for (index = 0; index<modelCount; index++)
	{
		m_ModelList->GetData(index, positionX, positionY, positionZ, color);
		radius = 1.0f;
		renderModel = m_Frustum->CheckSphere(positionX, positionY, positionZ, radius);
		if (renderModel)
		{
			D3DXMatrixRotationY(&worldMatrix, rotation);
			temp = worldMatrix;
			D3DXMatrixTranslation(&worldMatrix, positionX, positionY, positionZ);
			D3DXMatrixMultiply(&worldMatrix, &temp, &worldMatrix);

			m_Model->Render(m_D3D->GetDeviceContext());
			m_LightShader->Render(m_D3D->GetDeviceContext(), m_Model->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix,
			m_Model->GetTexture(), m_Light->GetDirection(), m_Light->GetDiffuseColor(),m_Light->GetAmbientColor(),m_Camera->GetPosition(),m_Light->GetSpecularColor(),m_Light->GetSpecularPower());
			m_D3D->GetWorldMatrix(worldMatrix);
			renderCount++;
		}
	}

	// Set the number of models that was actually rendered this frame.
	result = m_Text->SetRenderCount(renderCount, m_D3D->GetDeviceContext());
	if (!result)
	{
		return false;
	}

	m_D3D->TurnZBufferOff();
	m_D3D->TurnOnAlphaBlending();

	result = m_Text->Render(m_D3D->GetDeviceContext(), worldMatrix, orthoMatrix);
	if (!result) {
		return false;
	}
	m_D3D->TurnOffAlphaBlending();
	m_D3D->TurnZBufferOn();
	// ���ۿ� �׷��� ���� ȭ�鿡 ���
	m_D3D->EndScene();
	return true;
}
