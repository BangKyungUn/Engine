#pragma once



#include <vector>
#include <d3d11.h>
#include <D3DX10math.h>
#include <fstream>
#include <string>
using namespace std;

#include "TextureClass.h"

// assimp
#include "assimp\Importer.hpp"
#include "assimp\cimport.h"
#include "assimp\postprocess.h"
#include "assimp\scene.h"
#pragma comment(lib,"assimp.lib")

class ModelClass
{
private:
	struct VertexType // ���� ���ۿ� ����� ����ü ���� -> ColorShaderClass ���� ����� �Ͱ� ������ ���ƾ��Ѵ�.
	{
		D3DXVECTOR3 position;
		D3DXVECTOR2 texture;
		D3DXVECTOR3 normal;
	};
	struct ModelType
	{
		float x, y, z;
		float tu, tv;
		float nx, ny, nz;

		std::vector<VertexType> m_vertices;
		std::vector<int> m_indices;
	};
public:
	ModelClass();
	ModelClass(const ModelClass&);
	~ModelClass();
	bool Initialize(ID3D11Device*,std::string, WCHAR*);
	bool Initialize(ID3D11Device*, char*,WCHAR*);
	void Shutdown();
	void Render(ID3D11DeviceContext*);
	int GetIndexCount();
	ID3D11ShaderResourceView* GetTexture();

private:
	bool InitializeBuffersFbx(ID3D11Device*);
	bool InitializeBuffersNormal(ID3D11Device*);
	void ShutdownBuffers();
	void RenderBuffers(ID3D11DeviceContext*);
	bool LoadTexture(ID3D11Device*, WCHAR*);
	void ReleaseTexture();
	bool LoadModel(char*);
	void ReleaseModel();

	// Fbx Parsing
	bool LoadMesh(std::string);

	ID3D11Buffer *m_vertexBuffer, *m_indexBuffer;
	int m_vertexCount, m_indexCount;
	TextureClass *m_Texture;
	ModelType *m_model;
	vector<UINT> indices;
	VertexType *vertices;
};

